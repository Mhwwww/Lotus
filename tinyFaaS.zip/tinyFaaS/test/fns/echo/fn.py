#!/usr/bin/env python3

import typing

def fn(input: typing.Optional[str]) -> typing.Optional[str]:
    """echo the input"""
    return input
