#!/bin/sh

# read from stdin into a variable
INPUT=$(cat)

# echo the variable to stdout
echo -n "$INPUT"

