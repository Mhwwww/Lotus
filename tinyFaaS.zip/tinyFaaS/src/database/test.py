import boto3

dynamodb = boto3.resource('dynamodb', endpoint_url='http://localhost:8000', region_name='eu-center-1')
table_name = 'my-table'

table = dynamodb.create_table(
    TableName=table_name,
    KeySchema=[
        {
            'AttributeName': 'id',
            'KeyType': 'HASH'
        }
    ],
    AttributeDefinitions=[
        {
            'AttributeName': 'id',
            'AttributeType': 'S'
        }
    ],
    ProvisionedThroughput={
        'ReadCapacityUnits': 5,
        'WriteCapacityUnits': 5
    }
)
#wait for table to be created
table.meta.client.get_waiter('table_exists').wait(TableName=table_name)

item = {
    'id': '1',
    'name': 'John Doe'
}

table.put_item(Item=item)
